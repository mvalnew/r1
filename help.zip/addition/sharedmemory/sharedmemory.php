<?php
    include($_SERVER['DOCUMENT_ROOT'].'/modules/functions.php');
    setHTML(200, 201, "script200.js");
?>